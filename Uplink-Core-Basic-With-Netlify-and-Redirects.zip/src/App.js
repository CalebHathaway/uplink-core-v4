
import React, { useState } from 'react';
import './App.css';

function App() {
  const [form, setForm] = useState({ reward: '', promo: '', amount: '' });
  const [entries, setEntries] = useState([]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setEntries([...entries, form]);
    setForm({ reward: '', promo: '', amount: '' });
  };

  const eligible = entries.filter(e => ['Yes', 'No', 'Not Asked'].includes(e.reward));
  const signups = eligible.filter(e => e.reward === 'Yes');
  const attachRate = eligible.length > 0 ? ((signups.length / eligible.length) * 100).toFixed(1) + '%' : '0%';

  return (
    <div className="App">
      <h1>Uplink Core</h1>
      <form onSubmit={handleSubmit}>
        <label>Rewards:</label>
        <select name="reward" value={form.reward} onChange={handleChange}>
          <option value="">-- Select --</option>
          <option value="Yes">Yes</option>
          <option value="No">No</option>
          <option value="Already Had">Already Had</option>
          <option value="Not Asked">Not Asked</option>
        </select><br/>
        
        <label>Paper Promo:</label>
        <select name="promo" value={form.promo} onChange={handleChange}>
          <option value="">-- Select --</option>
          <option value="Yes">Yes</option>
          <option value="No">No</option>
          <option value="N/A">N/A</option>
        </select><br/>
        
        <label>Amount ($):</label>
        <input type="number" name="amount" value={form.amount} onChange={handleChange} /><br/>

        <button type="submit">Submit</button>
      </form>

      <h2>Attach Rate: {attachRate}</h2>
      <ul>
        {entries.map((e, i) => (
          <li key={i}>
            Rewards: {e.reward} | Promo: {e.promo} | Amount: ${e.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
